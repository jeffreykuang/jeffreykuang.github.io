function [f]=computeObjective(u)
   global Ahat_plus;
    global Ahat_minus;
   global Ar;
   global Gradient;
   global DimensionX;
   
%    global DimensionY;
% tmp=Ahat_plus; %z;
% Ahat=zhkuang_constructAhat(u);
% tmp=tmp-Ahat;
  
  Ahat=constructAhat(u);
  
 
 [Ahat_plus,Ahat_minus]=eigenDecomposeSymmetricMatrix(Ahat);
  
 
 
% disp('call objective function once');
f=double(0.5*(sum(sum(Ahat_minus.*Ahat_minus)))-sum(u));
% fprintf('objetive=%f \n',f);
totalIter=1;
subRB=-Ahat_minus(DimensionX+1:end,DimensionX+1:end);
         tmpRB_DIAG=diag(subRB);
         tmpRB_TRIL=subRB(tril(true( size(subRB) ),-1 ));
         tmpR=-Ahat_minus(1:DimensionX,DimensionX+1:end);
         subLT=-Ahat_minus(1:DimensionX,1:DimensionX);
         tmpLT_DIAG=diag(subLT);
         tmpLT_TRIL=subLT(tril(true( size(subLT) ),-1 ));
         tmpL=-Ahat_minus(DimensionX+1:end,1:DimensionX);
for i=1:4
    if ~isempty(Ar{i})
        
       switch (i)
           case 1
             
               
               for iter=1:size(Ar{i}.RB_TRIL,2)
               g=sum(Ar{i}.RB_TRIL(:,iter).*tmpRB_TRIL)*2;
               g=g+sum(sum(Ar{i}.R(:,:,iter).*tmpR))*2;
               g=g+sum(Ar{i}.RB_DIAG(:,iter).*tmpRB_DIAG);
               Gradient(totalIter)=g-1;
               totalIter=totalIter+1;
               end
               
           case 2
               for iter=1:size(Ar{i}.LT_TRIL,2)
               g=sum(Ar{i}.LT_TRIL(:,iter).*tmpLT_TRIL)*2;
               g=g+sum(Ar{i}.LT_DIAG(:,iter).*tmpLT_DIAG);
               Gradient(totalIter)=g-1;
               totalIter=totalIter+1;
               end
           case 3
               for iter=1:size(Ar{i}.RB_TRIL,2)
               g=sum(Ar{i}.RB_TRIL(:,iter).*tmpRB_TRIL)*2;
               g=g+sum(Ar{i}.RB_DIAG(:,iter).*tmpRB_DIAG);
               Gradient(totalIter)=g-1;
               totalIter=totalIter+1;
               end
           case 4
               for iter=1:size(Ar{i}.LT_TRIL,2)
               g=sum(Ar{i}.LT_TRIL(:,iter).*tmpLT_TRIL)*2;
               g=g+sum(sum(Ar{i}.L(:,:,iter).*tmpL))*2;
               g=g+sum(Ar{i}.LT_DIAG(:,iter).*tmpLT_DIAG);
               Gradient(totalIter)=g-1;
               totalIter=totalIter+1;
               end
               
    end
end


% for i=1:l
%  Gradient(i)=sum(sum(Ar(:,:,i).*tmp))-1;
% end
% fprintf('invoke objective function\n');
% fprintf('u=%0.3g %0.3g %0.3g \n', u(1),u(2),u(3));
% fprintf('f=%0.3g \n', f);
end
