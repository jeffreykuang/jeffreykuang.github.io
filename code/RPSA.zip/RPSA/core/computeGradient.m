function [G]=computeGradient(u)
global Gradient;
G=double(Gradient);
% disp('call gradient once');
%  global Ahat_plus;
%  global Ar;
%  tmp=Ahat_plus;
%   [r,c,l]=size(Ar);
% for i=1:l
%       tmp=tmp+Ar(:,:,i)*u(i);
% end
% G=zeros(l,1);
% for i=1:l
%  G(i)=sum(sum(Ar(:,:,i).*tmp))-1;
% end
% fprintf('Gradient=%0.3g %0.3g %0.3g \n', G(1),G(2),G(3));
end