function constructAr(Xn,Yn,Triplet,is_exist)

global Ar;
global DimensionX;
global DimensionY;
Ar=cell(4,1);
if is_exist
Ar=importdata('Ar.mat');
else
for i=1:4
    if ~isempty(Triplet{i})
       l=size(Triplet{i},1);
       switch (i)
           case 1
                   Ar{i}.R=zeros(DimensionX,DimensionY,l,'single');
                   Ar{i}.RB_TRIL=zeros(DimensionY*(DimensionY-1)/2,l,'single');
                   Ar{i}.RB_DIAG=zeros(DimensionY,l,'single');
                   for iter=1:l
                   t1=Xn(:,Triplet{i}(iter,1));
                   t2=Yn(:,Triplet{i}(iter,2));
                   t3=Yn(:,Triplet{i}(iter,3));
                   tmp=(t1-t3)*(t1-t3)'-(t1-t2)*(t1-t2)';
                   Ar{i}.R(:,:,iter)=single(tmp(1:DimensionX,DimensionX+1:end));
                   sub=tmp(DimensionX+1:end,DimensionX+1:end);
                   Ar{i}.RB_DIAG(:,iter)=single(diag(sub));
                  
                   Ar{i}.RB_TRIL(:,iter)=single(sub(tril(true( size(sub) ),-1 )));
                   end
                   clear t1;
                   clear t2;
                   clear t3;
                   clear sub;
                   clear tmp;
           case 2
                Ar{i}.LT_TRIL=zeros(DimensionX*(DimensionX-1)/2,1,'single');
                Ar{i}.LT_DIAG=zeros(DimensionX,1,'single');
                for iter=1:l
                   t1=Xn(:,Triplet{i}(iter,1));
                   t2=Xn(:,Triplet{i}(iter,2));
                   t3=Xn(:,Triplet{i}(iter,3));
                   tmp=(t1-t3)*(t1-t3)'-(t2-t3)*(t2-t3)';
                   sub=tmp(1:DimensionX,1:DimensionX);
                   Ar{i}.LT_DIAG(:,iter)=single(diag(sub));
                   Ar{i}.LT_TRIL(:,iter)=single(sub(tril(true(size(sub)),-1)));
                end
                clear t1;
                clear t2;
                clear t3;
                clear sub;
                clear tmp;
               
           case 3
                
                   Ar{i}.RB_TRIL=zeros(DimensionY*(DimensionY-1)/2,l,'single');
                   Ar{i}.RB_DIAG=zeros(DimensionY,l,'single');
                   for iter=1:l
                   t1=Yn(:,Triplet{i}(iter,1));
                   t2=Yn(:,Triplet{i}(iter,2));
                   t3=Yn(:,Triplet{i}(iter,3));
                   tmp=(t1-t3)*(t1-t3)'-(t1-t2)*(t1-t2)';
                   sub=tmp(DimensionX+1:end,DimensionX+1:end);
                   Ar{i}.RB_DIAG(:,iter)=single(diag(sub));
                   Ar{i}.RB_TRIL(:,iter)=single(sub(tril(true( size(sub) ),-1 )));
                   end
                   clear t1;
                   clear t2;
                   clear t3;
                   clear sub;
                   clear tmp;
               
           case 4
                Ar{i}.L=zeros(DimensionY,DimensionX,1,'single');
                Ar{i}.LT_TRIL=zeros(DimensionX*(DimensionX-1)/2,1,'single');
                Ar{i}.LT_DIAG=zeros(DimensionX,1,'single');
                for iter=1:l
                    t1=Xn(:,Triplet{i}(iter,1));
                    t2=Xn(:,Triplet{i}(iter,2));
                    t3=Yn(:,Triplet{i}(iter,3));
                    tmp=(t1-t3)*(t1-t3)'-(t2-t3)*(t2-t3)';
                    Ar{i}.L(:,:,iter)=single(tmp(DimensionX+1:end,1:DimensionX));
                    sub=tmp(1:DimensionX,1:DimensionX);
                    Ar{i}.LT_DIAG(:,iter)=single(diag(sub));
                    Ar{i}.LT_TRIL(:,iter)=single(sub(tril(true(size(sub)),-1)));
                end
                clear t1;
                clear t2;
                clear t3;
                clear tmp;
       end
       
        
    end
    
end

end


end
