function [Ahat]=constructAhat(u)
global Ar;
global DimensionX;
global DimensionY;
Ahat=zeros(DimensionX+DimensionY,DimensionX+DimensionY);
totalIter=1;
for i=1:4
    if ~isempty(Ar{i})
       switch (i)
           case 1
               RB_TRIL=zeros(DimensionY*(DimensionY-1)/2,1);
               RB_DIAG=zeros(DimensionY,1);
               R=zeros(DimensionX,DimensionY);
               for iter=1:size(Ar{i}.RB_TRIL,2)
               RB_TRIL=RB_TRIL-Ar{i}.RB_TRIL(:,iter)*u(totalIter);
               RB_DIAG=RB_DIAG-Ar{i}.RB_DIAG(:,iter)*u(totalIter);
               R=R-Ar{i}.R(:,:,iter)*u(totalIter);
               totalIter=totalIter+1;
               end
               Ahat=Ahat+[zeros(DimensionX,DimensionX),R;R',squareform(RB_TRIL)+diag(RB_DIAG)];
               clear RB_TRIL;
               clear RB_DIAG;
               clear R;
           case 2
               LT_TRIL=zeros(DimensionX*(DimensionX-1)/2,1);
               LT_DIAG=zeros(DimensionX,1);
               
               for iter=1:size(Ar{i}.LT_TRIL,2)
               LT_TRIL=LT_TRIL-Ar{i}.LT_TRIL(:,iter)*u(totalIter);
               LT_DIAG=LT_DIAG-Ar{i}.LT_DIAG(:,iter)*u(totalIter);
               totalIter=totalIter+1;
               end
               Ahat=Ahat+[squareform(LT_TRIL)+diag(LT_DIAG),zeros(DimensionX,DimensionY);zeros(DimensionY,DimensionX),zeros(DimensionY,DimensionY)];
               clear LT_TRIL;
               clear LT_DIAG;
               clear L;
               
           case 3
               RB_TRIL=zeros(DimensionY*(DimensionY-1)/2,1);
               RB_DIAG=zeros(DimensionY,1);
               for iter=1:size(Ar{i}.RB_TRIL,2)
               RB_TRIL=RB_TRIL-Ar{i}.RB_TRIL(:,iter)*u(totalIter);
               RB_DIAG=RB_DIAG-Ar{i}.RB_DIAG(:,iter)*u(totalIter);
               totalIter=totalIter+1;
               end
               Ahat=Ahat+[zeros(DimensionX,DimensionX),zeros(DimensionX,DimensionY);zeros(DimensionY,DimensionX),squareform(RB_TRIL)+diag(RB_DIAG)];
               clear RB_TRIL;
               clear RB_DIAG;
           case 4
               LT_TRIL=zeros(DimensionX*(DimensionX-1)/2,1);
               LT_DIAG=zeros(DimensionX,1);
               L=zeros(DimensionY,DimensionX);
               for iter=1:size(Ar{i}.LT_TRIL,2)
               LT_TRIL=LT_TRIL-Ar{i}.LT_TRIL(:,iter)*u(totalIter);
               LT_DIAG=LT_DIAG-Ar{i}.LT_DIAG(:,iter)*u(totalIter);
               L=L-Ar{i}.L(:,:,iter)*u(totalIter);
               totalIter=totalIter+1;
               end
               Ahat=Ahat+[squareform(LT_TRIL)+diag(LT_DIAG),L';L,zeros(DimensionY,DimensionY)];
               clear LT_TRIL;
               clear LT_DIAG;
               clear L;
               
    end
end

% for i=1:l
%     Ahat=Ahat-Ar(:,:,i)*u(i);
% end

end
