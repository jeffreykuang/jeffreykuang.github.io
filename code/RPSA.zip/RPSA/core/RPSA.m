function [Wx,Wy,Ax,Ay]=RPSA(X,Y,Triplet,param)
%each column of X is an instance with m dimension.
%each column of Y is an instance with n dimension. 
%X is m by T matrix while Y is n by T matrix. Triplet is a stack with elements(i,j,k)
%(i,j,k) means distance(i,k)>=distance(i,j)
[m,T]=size(X);
[n,T]=size(Y);
global DimensionX;
global DimensionY;
global Ahat_plus;
global Ahat_minus;
global Ar;
global Gradient;
DimensionX=m;
DimensionY=n;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%We suppose X_i are mapped into latent space by Wx*X_i and Y_i by Wy*Y_i.
%%Let W=[Wx,Wy]. Therefore, Wx=W*Ax Wy=W*Ay with Ax=[I;0] and Ay=[0;I].
%%The distance of X_i and Y_i is defined by
%%||Wx*X_i-Wy*Y_i||^2=||W*Xn_i-W*Yn_i||^2.

Ax=[eye(m);zeros(n,m)];
Ay=[zeros(m,n);eye(n)];
Xn=(Ax*X);
Yn=(Ay*Y);
[W2]=dualOpt(Xn,Yn,Triplet,param);
[W]=getProjection(W2);
Wx=W*Ax;
Wy=W*Ay;
clear DimensionX;
clear DimensionY;
clear Ahat_minus;
clear  Ahat_plus;
clear Ahat_minus;
clear Ar;
clear Gradient;
end