function genericcallback (t, f, x)
 fprintf('iter=%3d  objective function=%0.3g \n', t, f);