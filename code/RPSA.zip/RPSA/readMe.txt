Welcome to RPSA demo.  It is tested on 64 bit windows 8 (Matlab 2012a).



1> Run CMUPIEDemo.m



Notice:
1. This code is only for demostration. Parameters such as the number of triplets and that of iterations can be tuned to achieve
better results.
----------------------------------------------------------------------------------
This demo is for academic purpose only. Not for commercial/industrial activities.
Any bug report or discussion is highly appreciated. 
Zhanghui Kuang
kuangzhh@gmail.com
-----------------------------------------------------------------------------------
If you use/adapt our code, please appropriately cite our paper by:
Zhanghui Kuang, Kwan-Yee Wong.: Relatively-Paired Space Analysis. In: BMVC (2013)
-----------------------------------------------------------------------------------


