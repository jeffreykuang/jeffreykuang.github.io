function triplets=constructTriplets(L,Xn,Yn,Labels,type,num_pairs)
  triplets=cell(4,1);
  num=length(L);
  for i=1:4
     if type(i)==1
    
     switch (i)
         case 1
             % d(x_i,y_k)-d(x_i,x_j)>=0
             triplets{i}=zeros(num*num_pairs(i),3);
             for iter=1:num
             tmp=zhkuang_findOtherViewComparison(L(iter), Xn,Yn,Labels, i,num_pairs(i));
             triplets{i}((iter-1)*num_pairs(i)+1:iter*num_pairs(i),:)=[L(iter)*ones(num_pairs(i),2),tmp];
             end
         case 2
             triplets{i}=zeros(num*num_pairs(i),3);
             for iter=1:num
             tmp=zhkuang_findOneViewComparison(L(iter), Xn,Labels, num_pairs(i));
             triplets{i}((iter-1)*num_pairs(i)+1:iter*num_pairs(i),:)=[L(iter)*ones(num_pairs(i),1),tmp];
             end
         case 3
             triplets{i}=zeros(num*num_pairs(i),3);
             for iter=1:num
             tmp=zhkuang_findOneViewComparison(L(iter), Yn,Labels, num_pairs(i));
             triplets{i}((iter-1)*num_pairs(i)+1:iter*num_pairs(i),:)=[L(iter)*ones(num_pairs(i),1),tmp];
             end
             
         case 4
             triplets{i}=zeros(num*num_pairs(i),3);
             for iter=1:num
             tmp=zhkuang_findOtherViewComparison(L(iter), Xn,Yn,Labels, i,num_pairs(i));
             triplets{i}((iter-1)*num_pairs(i)+1:iter*num_pairs(i),:)=[tmp,L(iter)*ones(num_pairs(i),2)];
             end   
     end
  end
       
  end
end
%   comparisonNum=9;
%   for i=1:num
%    [index]=find(L~=L(i));
%    r=randperm(length(index));
%    instanceIndex=index(r(1:comparisonNum));
%    submatrix=repmat(i,comparisonNum,2);
%    triplets=[triplets; [submatrix,instanceIndex']];
%   end
% 
%   end
function comparisonIndex=zhkuang_findOneViewComparison(index, data,Labels,num_pairs)
      myLabel=Labels(index);
      sameLabelIndex=find((Labels==myLabel));
      num_sameLabel=length(sameLabelIndex);
      distanceSameLabel=zeros(num_sameLabel,1);
      for i=1:num_sameLabel
      distanceSameLabel(i)=norm(data(:,index)-data(:,sameLabelIndex(i)),2);
      end
      [v,sortIndexSameLabel]=sort(distanceSameLabel);
      comparisonIndex=zeros(num_pairs,2);
      comparisonIndex(:,1)=sameLabelIndex(sortIndexSameLabel(2:num_pairs+1));
      
      differentLabelIndex=find(Labels~=myLabel);
      num_differentLabel=length(differentLabelIndex);
      distanceDifferentLabel=zeros(num_differentLabel,1);
      for i=1:num_differentLabel
      distanceDifferentLabel(i)=norm(data(:,index)-data(:,differentLabelIndex(i)),2);
      end
      [v,sortIndexDifferentLabel]=sort(distanceDifferentLabel);
      comparisonIndex(:,2)=differentLabelIndex(sortIndexDifferentLabel(1:num_pairs));
      
      
end
function comparisonIndex=zhkuang_findOtherViewComparison(index, Xn,Yn,Labels, type,num_pairs)
if type==1
   %finding amongst Yn
   base=Yn(:,index);
   I=find(Labels~=Labels(index));
   N=length(I);
   distance=zeros(N,1);
   for i=1:N
       distance(i)=norm(Yn(:,I(i))-base,2);
   end
   [v,II]=sort(distance);
   comparisonIndex=I(II(1:num_pairs));
   
elseif type==4
   %finding amongst Xn
   base=Xn(:,index);
   I=find(Labels~=Labels(index));
   N=length(I);
   distance=zeros(N,1);
   for i=1:N
       distance(i)=norm(Xn(:,I(i))-base,2);
   end
   [v,II]=sort(distance);
   comparisonIndex=I(II(1:num_pairs));
end

end
  